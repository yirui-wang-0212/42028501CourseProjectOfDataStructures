#include"examinee_class.h"

//print this node's information
void Examinee::Output() {

	cout << num_ << "       "
		<< name_ << "    "
		<< gender_ << "      "
		<< age_ << "      "
		<< category_ << endl;
}